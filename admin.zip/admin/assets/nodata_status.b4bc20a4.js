const a="/admin/images/nodata_status.png";export{a as _};
