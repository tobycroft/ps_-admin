const a="/admin/icons/avatar_icon.png";export{a as _};
