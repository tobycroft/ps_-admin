const i="/admin/icons/edit_icon.png";export{i as _};
